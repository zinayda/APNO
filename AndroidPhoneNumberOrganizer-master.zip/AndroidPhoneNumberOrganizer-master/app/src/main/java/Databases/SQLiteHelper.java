package Databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import Models.Contact;

public class SQLiteHelper extends SQLiteOpenHelper {

    SQLiteDatabase mDB;
    private static final String TABLE_NAME = "contacts";
    private static final String COL0 = "ID";
    private static final String COL1 = "Name";
    private static final String COL2 = "Number";
    private static final String COL3 = "Category";
    private static final String COL4 = "Description";

    public SQLiteHelper(Context context) {
        super(context, TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "( ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL1 + " TEXT," + COL2 + " TEXT," + COL3 + " TEXT," + COL4 + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public ArrayList<Contact> getContacts() {
        mDB = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = mDB.rawQuery(query, null);

        ArrayList<Contact> tempList = new ArrayList<Contact>();

        while (data.moveToNext()) {
            Contact tempContact = new Contact();
            tempContact.ID = data.getInt(0);
            tempContact.Name = data.getString(1);
            tempContact.Number = data.getString(2);
            tempContact.Category = data.getString(3);
            tempContact.Description = data.getString(4);

            tempList.add(tempContact);
        }

        return tempList;
    }

    public boolean deleteContact(Integer id){
        mDB = this.getWritableDatabase();
        long result = mDB.delete(TABLE_NAME,"ID="+id,null);
        return determineIfActionWasSucc(result);
    }

    public boolean addContact(Contact contact) {
        mDB = this.getWritableDatabase();
        long result = mDB.insert(TABLE_NAME, null, createContentValuesForContact(contact));

        return determineIfActionWasSucc(result);
    }

    public boolean updateContact(Contact contact) {
        mDB = this.getWritableDatabase();
        long result = mDB.update(TABLE_NAME, createContentValuesForContact(contact),
                "ID=" + contact.ID, null);

        return determineIfActionWasSucc(result);
    }

    private ContentValues createContentValuesForContact(Contact contact) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL0, contact.ID);
        contentValues.put(COL1, contact.Name);
        contentValues.put(COL2, contact.Number);
        contentValues.put(COL3, contact.Category);
        contentValues.put(COL4, contact.Description);

        return contentValues;
    }

    private boolean determineIfActionWasSucc(long result){
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }
}
