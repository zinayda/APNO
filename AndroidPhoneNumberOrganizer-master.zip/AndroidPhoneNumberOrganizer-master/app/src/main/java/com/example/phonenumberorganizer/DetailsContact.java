package com.example.phonenumberorganizer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import Constants.IntentConstants;
import Databases.SQLiteHelper;
import Models.Contact;
import Services.ToastService;

public class DetailsContact extends AppCompatActivity {
    ToastService mToastService;
    SQLiteHelper mDB;
    Contact selectedContact;
    TextView editName;
    TextView editNumber;
    TextView editCategory;
    TextView editDescription;
    Button editDetailsBtn;
    Button deleteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDB = new SQLiteHelper(this);
        mToastService = new ToastService(this);
        setContentView(R.layout.activity_details_contact);
        getViews();
        final Intent intent = getIntent();
        selectedContact = (Contact) intent.getSerializableExtra(IntentConstants.CONTACT);
        populateDetails();

        editDetailsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailsIntent = new Intent(DetailsContact.this, EditContact.class);
                detailsIntent.putExtra(IntentConstants.CONTACT, selectedContact);
                startActivity(detailsIntent);
                finish();
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isSucc = mDB.deleteContact(selectedContact.ID);

                if (isSucc) {
                    mToastService.raiseMsg(selectedContact.Name + " is deleted!");
                    finish();
                }
                else{
                    mToastService.raiseMsg("Action failed!");
                }
            }
        });
    }

    private void populateDetails() {
        editDescription.setText(selectedContact.Description);
        editName.setText(selectedContact.Name);
        editNumber.setText(selectedContact.Number);
        editCategory.setText(selectedContact.Category);
    }

    private void getViews() {
        editName = findViewById(R.id.detailsName);
        editNumber = findViewById(R.id.detailsNumber);
        editCategory = findViewById(R.id.detailsCategory);
        editDescription = findViewById(R.id.detailsDesc);
        editDetailsBtn = findViewById(R.id.editDetailsBtn);
        deleteBtn = findViewById(R.id.delBtn);
    }
}
