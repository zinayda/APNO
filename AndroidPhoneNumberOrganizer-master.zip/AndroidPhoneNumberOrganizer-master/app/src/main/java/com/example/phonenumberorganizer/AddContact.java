package com.example.phonenumberorganizer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import Databases.SQLiteHelper;
import Models.Contact;
import Services.ToastService;

public class AddContact extends AppCompatActivity {
    ToastService mToastService;
    SQLiteHelper mDB;
    TextView addEditName;
    TextView addEditNumber;
    Spinner addEditCategory;
    TextView addEditDescription;
    Button addEditBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_contact);
        mDB = new SQLiteHelper(this);
        mToastService = new ToastService(this);
        getAddViews();

        addEditBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contact tempContact = getContactFromForm();

                if(tempContact.Name.isEmpty() || tempContact.Number.isEmpty()){
                    mToastService.raiseMsg("Name and Number are required! Please input them.");
                }
                else{

                    boolean isSucc = mDB.addContact(tempContact);

                    if(isSucc){
                        mToastService.raiseMsg(tempContact.Name + " is added!");
                        finish();
                    }
                    else{
                        mToastService.raiseMsg("Operation failed!");
                    }

                }
            }
        });
    }

    private void getAddViews(){
        addEditName = findViewById(R.id.addEditName);
        addEditNumber = findViewById(R.id.addEditNumber);
        addEditCategory = findViewById(R.id.addEditCategory);
        addEditDescription = findViewById(R.id.addEditDescription);
        addEditBtn = findViewById(R.id.addEditBtn);
    }

    private Contact getContactFromForm(){
        Contact tempContact = new Contact();
        tempContact.Name = addEditName.getText().toString();
        tempContact.Number = addEditNumber.getText().toString();
        tempContact.Category = addEditCategory.getSelectedItem().toString();
        tempContact.Description = addEditDescription.getText().toString();

        return tempContact;
    }
}
