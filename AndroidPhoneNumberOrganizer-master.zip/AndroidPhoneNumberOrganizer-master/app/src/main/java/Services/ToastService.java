package Services;

import android.content.Context;
import android.widget.Toast;

public class ToastService {

    Context context;

    public ToastService(Context context){
        this.context = context;
    }

    public void raiseMsg(String msg){
        Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
    }
}
