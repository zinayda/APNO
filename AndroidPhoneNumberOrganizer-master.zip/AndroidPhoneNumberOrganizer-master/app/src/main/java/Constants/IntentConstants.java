package Constants;

public class IntentConstants {
    public static final String CONTACT = "Contact";
}
