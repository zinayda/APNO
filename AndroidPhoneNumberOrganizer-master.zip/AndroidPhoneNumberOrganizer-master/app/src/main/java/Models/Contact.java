package Models;

import java.io.Serializable;

public class Contact implements Serializable {

    public Integer ID;
    public String Name;
    public String Number;
    public String Category;
    public String Description;
}
